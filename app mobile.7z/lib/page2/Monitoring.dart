import 'DataHistory.dart';
import 'package:fixed_011/page_auth/login.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:fixed_011/data_firebase/read.dart';
import 'package:fixed_011/package/card.dart';


class Monitoring extends StatelessWidget {
  const Monitoring({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: RealtimeSensorDataPage(),
    );
  }
}

class RealtimeSensorDataPage extends StatefulWidget {
  const RealtimeSensorDataPage({super.key});

  @override
  _RealtimeSensorDataPageState createState() => _RealtimeSensorDataPageState();
}

class _RealtimeSensorDataPageState extends State<RealtimeSensorDataPage> {
  final Database db = Database();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  late Stream<DatabaseEvent> _dataStream;

  @override
  void initState() {
    super.initState();
    _dataStream = db.listenToData(path: 'sensorData');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      
        endDrawer: Drawer(
        child: Scrollbar(
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                width: double.infinity,
                height: 120,
                color: const Color.fromARGB(211, 19, 97, 42),
                alignment: Alignment.bottomLeft,
                child: const Text(
                  "Setting",
                  style: TextStyle(
                    color: Color.fromARGB(255, 247, 249, 250),
                    fontSize: 25,
                  ),
                ),
              ),
              ListTile(
                onTap: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => const Monitoring(),
                    ),
                  );
                },
                leading: const Icon(Icons.sunny, size: 35),
                title: const Text(
                  "Monitoring",
                  style: TextStyle(fontSize: 24),
                ),
              ),
              ListTile(
                onTap: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => const DataHistory(),
                    ),
                  );
                },
                leading: const Icon(Icons.history, size: 35),
                title: const Text(
                  "Histori",
                  style: TextStyle(fontSize: 24),
                ),
              ),
              ListTile(
                onTap: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => const Login(),
                    ),
                  );
                },
                leading: const Icon(
                  Icons.logout_sharp,
                  color: Colors.red,
                  size: 35,
                ),
                title: const Text(
                  "Logout",
                  style: TextStyle(
                    color: Colors.red,
                    fontWeight: FontWeight.bold,
                    fontSize: 24,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),

      body: Stack(
        children: [
          Column(
            children: [
              Expanded(
                child: Container(
                  decoration: const BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage('lib/assets/monitoring.png'),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 220),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Text(
                  'Monitoring\nGreen House',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 30,
                    fontWeight: FontWeight.bold,
                    shadows: [
                      Shadow(
                        offset: const Offset(5.0, 5.0),
                        blurRadius: 3.0,
                        color: Colors.black.withOpacity(0.3),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 35),
              Expanded(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(30),
                      topRight: Radius.circular(30),
                    ),
                  ),
                  child: StreamBuilder<DatabaseEvent>(
                    stream: _dataStream,
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return const Center(child: CircularProgressIndicator());
                      }

                      if (snapshot.hasError) {
                        
                      }

                      if (!snapshot.hasData || snapshot.data!.snapshot.value == null) {
                        
                      }

                      final data = (snapshot.data!.snapshot.value as Map).entries.toList()
                        ..sort((a, b) => b.key.compareTo(a.key));
                      final latestData = data.first;

                      return ListView(
                        children: [
                          Card(
                            child: ListTile(
                              title: const Text('Realtime Data',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 20,
                              ),
                              ),
                              
                              subtitle: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const SizedBox(height: 10),
                                  SensorCard(
                                    icon: Icons.wb_sunny_outlined,
                                    label: 'Light',
                                    value: Text('${latestData.value['cahaya']}'),
                                    color: Colors.yellow,
                                  ),
                                  SensorCard(
                                    icon: Icons.water_drop_outlined,
                                    label: 'Humidity',
                                    value: Text('${latestData.value['humidity']}'),
                                    color: Colors.blueAccent,
                                  ),
                                  SensorCard(
                                    icon: Icons.thermostat_outlined,
                                    label: 'Temperature',
                                    value: Text('${latestData.value['temperature']}'),
                                    color: Colors.orange,
                                  ),
                                  SensorCard(
                                    icon: Icons.grass,
                                    label: 'Soil Moisture',
                                    value: Text('${latestData.value['soil']}'),
                                    color: Colors.green,
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const Divider(),
                        ],
                      );
                    },
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
