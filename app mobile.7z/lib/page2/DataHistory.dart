import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';

import '../page_auth/login.dart';
import 'Monitoring.dart';

class DataHistory extends StatefulWidget {
  const DataHistory({super.key});

  @override
  _DataHistoryState createState() => _DataHistoryState();
}

class _DataHistoryState extends State<DataHistory> {
  final DatabaseReference _databaseReference = FirebaseDatabase.instance.ref('sensorData'); 

  late Stream<DatabaseEvent> _dataStream;

  @override
  void initState() {
    super.initState();
    _dataStream = _databaseReference.onValue;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        automaticallyImplyLeading: false,
      ),
      endDrawer: Drawer(
        child: Scrollbar(
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                width: double.infinity,
                height: 120,
                color: const Color.fromARGB(211, 19, 97, 42),
                alignment: Alignment.bottomLeft,
                child: const Text(
                  "Setting",
                  style: TextStyle(
                    color: Color.fromARGB(255, 247, 249, 250),
                    fontSize: 25,
                  ),
                ),
              ),
              ListTile(
                onTap: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => const Monitoring(),
                    ),
                  );
                },
                leading: const Icon(Icons.sunny, size: 35),
                title: const Text(
                  "Monitoring",
                  style: TextStyle(fontSize: 24),
                ),
              ),
              ListTile(
                onTap: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => const DataHistory(),
                    ),
                  );
                },
                leading: const Icon(Icons.history, size: 35),
                title: const Text(
                  "Histori",
                  style: TextStyle(fontSize: 24),
                ),
              ),
              ListTile(
                onTap: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => const Login(),
                    ),
                  );
                },
                leading: const Icon(
                  Icons.logout_sharp,
                  color: Colors.red,
                  size: 35,
                ),
                title: const Text(
                  "Logout",
                  style: TextStyle(
                    color: Colors.red,
                    fontWeight: FontWeight.bold,
                    fontSize: 24,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 10),
            Expanded(
              child: StreamBuilder<DatabaseEvent>(
                stream: _dataStream,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }

                  if (snapshot.hasError) {
                    
                  }

                  if (!snapshot.hasData ||snapshot.data!.snapshot.value == null) {
                    
                  }

                 
                  final data = (snapshot.data!.snapshot.value as Map).entries.toList();

                 
                  final Map<String, List<MapEntry>> groupedData = {};
                  for (var entry in data) {
                    final sensor = entry.value;
                    final timestamp = sensor['timestamp'];
                    final date = DateTime.parse(timestamp)
                        .toIso8601String()
                        .substring(0, 10);

                    groupedData.putIfAbsent(date, () => []);
                    groupedData[date]!.add(entry);
                  }

                  
                  final dates = groupedData.keys.toList()..sort();
                                   
                  return ListView.builder(
                    itemCount: dates.length,
                    itemBuilder: (context, index) {
                      final date = dates[index];
                      final items = groupedData[date]!;
                    
                            
return Card(
  margin: const EdgeInsets.symmetric(vertical: 8),
  child: ExpansionTile(
    title: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Data History', 
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 20,),
        ),
        const SizedBox(height: 10),
        Text(
          'Date: $date',
          style: const TextStyle(
            fontSize: 16, 
            fontWeight: FontWeight.bold, 
          ),
        ),
      ],
    ),
    children: items.map((entry) {
      final sensor = entry.value;
      return ListTile(
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Light       : ${sensor['cahaya']}'),
            Text('Humidity    : ${sensor['humidity']}'),
            Text('Soil        : ${sensor['soil']}'),
            Text('Temperature : ${sensor['temperature']}°C'),
          ],
        ),
      );
    }).toList(),
  ),
);

                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}