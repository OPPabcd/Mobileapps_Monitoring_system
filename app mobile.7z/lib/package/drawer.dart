// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
// import '../main.dart'; // Main app entry
// import '../page2/DataHistory.dart'; // Data history page
// import '../page2/Monitoring.dart'; // Monitoring page
// import '../page_auth/login.dart'; // Login page

// class MyDrawer extends StatelessWidget {
//   final String currentPage;

//   MyDrawer(this.currentPage);

//   @override
//   Widget build(BuildContext context) {
//     var currentDrawer = Provider.of<DrawerStateInfo>(context).getCurrentDrawer;

//     return Drawer(
//       child: Column(
//         children: [
//           Container(
//             padding: const EdgeInsets.all(20),
//             width: double.infinity,
//             height: 120,
//             color: const Color.fromARGB(211, 19, 97, 42),
//             alignment: Alignment.bottomLeft,
//             child: const Text(
//               "Settings",
//               style: TextStyle(
//                 color: Color.fromARGB(255, 247, 249, 250),
//                 fontSize: 25,
//               ),
//             ),
//           ),
//           Expanded(
//             child: ListView(
//               children: [
//                 DrawerListItem(
//                   icon: const Icon(Icons.sunny, size: 35),
//                   title: "Monitoring",
//                   destinationPage: Monitoring(),
//                   drawerIndex: 0,
//                 ),
//                 DrawerListItem(
//                   icon: const Icon(Icons.history, size: 35),
//                   title: "History",
//                   destinationPage: DataHistory(),
//                   drawerIndex: 1,
//                 ),
//                 DrawerListItem(
//                   icon: const Icon(Icons.logout_sharp, color: Colors.red, size: 35),
//                   title: "Logout",
//                   destinationPage: const Login(),
//                   drawerIndex: 2,
//                 ),
//               ],
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }

// class DrawerListItem extends StatelessWidget {
//   final Icon icon;
//   final String title;
//   final Widget destinationPage;
//   final int drawerIndex;

//   DrawerListItem({
//     required this.icon,
//     required this.title,
//     required this.destinationPage,
//     required this.drawerIndex,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return ListTile(
//       onTap: () {
//         Navigator.of(context).pop();
//         // Set the drawer index
//         Provider.of<DrawerStateInfo>(context, listen: false).setCurrentDrawer(drawerIndex);
//         // Navigate to the appropriate page
//         Navigator.of(context).pushReplacement(
//           MaterialPageRoute(builder: (context) => destinationPage),
//         );
//       },
//       leading: icon,
//       title: Text(
//         title,
//         style: TextStyle(fontSize: 24),
//       ),
//     );
//   }
// }
