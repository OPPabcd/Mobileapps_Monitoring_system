import 'package:firebase_database/firebase_database.dart';

class Database {
  final DatabaseReference _database = FirebaseDatabase.instance.ref();

  Stream<DatabaseEvent> listenToData({required String path}) {
    return _database.child(path).onValue;
  }
}
